package ru.geekbrains;

public class RunningTrack implements Action{
    // описываю мдлину дорожки

    int lengthRun;
    public void MembersRun(int lengthRun) {
        this.lengthRun = lengthRun;
    }

    @Override
    public void run() {

    }

    @Override
    public void jump() {

    }
}


