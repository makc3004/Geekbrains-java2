package ru.geekbrains;

public interface Action {
    void run();
    void jump();
}
